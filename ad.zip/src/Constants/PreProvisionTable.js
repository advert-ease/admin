export const preProvisionTable = [
  { id: 1, device_id: "12334", device_name: "phone1" },
  { id: 2, device_id: "12456", device_name: "phone2" },
  { id: 3, device_id: "12599", device_name: "phone4" },
  { id: 4, device_id: "12226", device_name: "phone5" },
  { id: 5, device_id: "12151", device_name: "phone6" },
  { id: 6, device_id: "12498", device_name: "phone7" },
  { id: 7, device_id: "12155", device_name: "phone8" },
  { id: 8, device_id: "12265", device_name: "phone9" },
  { id: 9, device_id: "12748", device_name: "phone10" },
];
