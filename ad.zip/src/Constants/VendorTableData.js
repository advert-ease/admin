export const vendorNames = [
  { id: 1, vendorName: "google" },
  { id: 2, vendorName: "goli" },
  { id: 3, vendorName: "venkateshwarasweets" },
  { id: 4, vendorName: "gopalRiceTraders" },
  { id: 5, vendorName: "sannidhiVeg" },
  { id: 6, vendorName: "Hotelsirimane" },
  { id: 7, vendorName: "JungleResorts" },
  { id: 8, vendorName: "SiritatteIdliCenter" },
  { id: 9, vendorName: "by2coffee" },
];
